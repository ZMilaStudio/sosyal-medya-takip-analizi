window.YTD.following.part0 = [
  {
    "following": {
      "accountId": "1001",
      "userLink": "https://x.com/demo_x_mutual01"
    }
  },
  {
    "following": {
      "accountId": "1002",
      "userLink": "https://x.com/demo_x_mutual02"
    }
  },
  {
    "following": {
      "accountId": "1003",
      "userLink": "https://x.com/demo_x_mutual03"
    }
  },
  {
    "following": {
      "accountId": "1004",
      "userLink": "https://x.com/demo_x_mutual04"
    }
  },
  {
    "following": {
      "accountId": "1005",
      "userLink": "https://x.com/demo_x_mutual05"
    }
  },
  {
    "following": {
      "accountId": "1201",
      "userLink": "https://x.com/demo_x_out01"
    }
  },
  {
    "following": {
      "accountId": "1202",
      "userLink": "https://x.com/demo_x_out02"
    }
  },
  {
    "following": {
      "accountId": "1203",
      "userLink": "https://x.com/demo_x_out03"
    }
  },
  {
    "following": {
      "accountId": "1204",
      "userLink": "https://x.com/demo_x_out04"
    }
  }
]
