window.YTD.follower.part0 = [
  {
    "follower": {
      "accountId": "1001",
      "userLink": "https://x.com/demo_x_mutual01"
    }
  },
  {
    "follower": {
      "accountId": "1002",
      "userLink": "https://x.com/demo_x_mutual02"
    }
  },
  {
    "follower": {
      "accountId": "1003",
      "userLink": "https://x.com/demo_x_mutual03"
    }
  },
  {
    "follower": {
      "accountId": "1004",
      "userLink": "https://x.com/demo_x_mutual04"
    }
  },
  {
    "follower": {
      "accountId": "1005",
      "userLink": "https://x.com/demo_x_mutual05"
    }
  },
  {
    "follower": {
      "accountId": "1102",
      "userLink": "https://x.com/demo_x_fan02"
    }
  },
  {
    "follower": {
      "accountId": "1103",
      "userLink": "https://x.com/demo_x_fan03"
    }
  },
  {
    "follower": {
      "accountId": "1301",
      "userLink": "https://x.com/demo_x_new01"
    }
  },
  {
    "follower": {
      "accountId": "1302",
      "userLink": "https://x.com/demo_x_new02"
    }
  }
]
